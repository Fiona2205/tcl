package com.shunlian.test;


import com.shunlian.guanchazhe.ConcreteObserver;
import com.shunlian.guanchazhe.ConcreteSubject;
import com.shunlian.guanchazhe.Observer;
import com.shunlian.pojo.Transactions;

public class ClientTest {
	
    public static void main(String[] args) {
    	
        //����һ������
        ConcreteSubject subject = new ConcreteSubject();
        //����һ���۲���
        Observer observer = new ConcreteObserver();
        //�۲�
        subject.addObserver(observer);
        //��ʼ����
        Transactions t1 = new Transactions();
        t1.setTradeId(1);
        t1.setVersion(1);
        t1.setSecurityCode("REL");
        t1.setQuantity(50);
        t1.setAction("INSERT");
        t1.setType("Buy");
        subject.add(t1);
        
        //��ʼ����
        Transactions t2 = new Transactions();
        t2.setTradeId(2);
        t2.setVersion(1);
        t2.setSecurityCode("ITC");
        t2.setQuantity(40);
        t2.setAction("INSERT");
        t2.setType("Sell");
        subject.add(t2);
        
        //��ʼ����
        Transactions t3 = new Transactions();
        t3.setTradeId(3);
        t3.setVersion(1);
        t3.setSecurityCode("INF");
        t3.setQuantity(70);
        t3.setAction("INSERT");
        t3.setType("Buy");
        subject.add(t3);
        
        Transactions t4= new Transactions();
        t4.setTradeId(1);
        t4.setVersion(2);
        t4.setSecurityCode("REL");
        t4.setQuantity(60);
        t4.setAction("UPDATE");
        t4.setType("Buy");
        subject.add(t4);
        
        
        Transactions t5 = new Transactions();
        t5.setTradeId(2);
        t5.setVersion(2);
        t5.setSecurityCode("ITC");
        t5.setQuantity(30);
        t5.setAction("CANCEL");
        t5.setType("Buy");
        subject.add(t5);
        
        Transactions t6 = new Transactions();
        t6.setTradeId(4);
        t6.setVersion(1);
        t6.setSecurityCode("INF");
        t6.setQuantity(20);
        t6.setAction("INSERT");
        t6.setType("Sell");
        subject.add(t6);
    }
}

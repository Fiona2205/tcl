package com.shunlian.pojo;

import java.util.concurrent.atomic.AtomicInteger;

public class Transactions {
	
	private static AtomicInteger transId = new AtomicInteger();
	
	private Integer transactionId;
	
	private Integer tradeId;
	
	private Integer version;
	
	private String securityCode;
	
	private Integer quantity;
	
	private String action;

	private String type;
	

	public Transactions() {
		super();
		this.transactionId = transId.getAndIncrement();
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public Integer getTradeId() {
		return tradeId;
	}

	public void setTradeId(Integer tradeId) {
		this.tradeId = tradeId;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", tradeId=" + tradeId + ", version=" + version
				+ ", securityCode=" + securityCode + ", quantity=" + quantity + ", action=" + action + ", type=" + type
				+ "]";
	}
	
}

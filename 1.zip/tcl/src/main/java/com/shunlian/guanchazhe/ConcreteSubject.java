package com.shunlian.guanchazhe;

import java.util.ArrayList;
import java.util.List;

import com.shunlian.pojo.Transactions;

public class ConcreteSubject extends Subject {

	private static List<Transactions> list = new ArrayList<Transactions>();
	
    //����ҵ��
    public void add(Transactions transactions) {
    	if(null == transactions) {
    		return;
    	}
    	//����������Ϣ
    	list.add(transactions);
    	//֪ͨ
        super.notifyObserver(transactions);
    }

}
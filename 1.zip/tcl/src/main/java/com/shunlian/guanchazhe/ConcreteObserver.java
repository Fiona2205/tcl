package com.shunlian.guanchazhe;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.shunlian.enums.ActionEnum;
import com.shunlian.enums.TypeEnum;
import com.shunlian.pojo.Transactions;

public class ConcreteObserver implements Observer {
	
	
	private static Map<String, Integer> map = new ConcurrentHashMap<String, Integer>();
	
	public void change(Transactions transactions) {
		System.out.println("�յ���Ϣ�����д���" + transactions.toString());
		String serCode = transactions.getSecurityCode();
		String type = transactions.getType();
		String action = transactions.getAction();
		Integer amtInteger = null;
		//���������serCode�Ѵ���
		if(map.containsKey(serCode)) {
			amtInteger = map.get(serCode);
			if(ActionEnum.INSERT.getCode().equals(action)) {
				if (TypeEnum.BUY.getCode().equals(type)) {
					amtInteger = amtInteger + transactions.getQuantity();
				}else if (TypeEnum.SELL.getCode().equals(type)) {
					amtInteger = amtInteger - transactions.getQuantity();
				}
			}else if(ActionEnum.UPDATE.getCode().equals(action)) {
				if (TypeEnum.BUY.getCode().equals(type)) {
					amtInteger = transactions.getQuantity();
				}else if (TypeEnum.SELL.getCode().equals(type)) {
					amtInteger = 0 - transactions.getQuantity();
				}
			}else if(ActionEnum.CANCEL.getCode().equals(action)) {
				amtInteger = 0;
			}
			
		}else {
			////���������serCode������
			if (TypeEnum.BUY.getCode().equals(type)) {
				amtInteger = transactions.getQuantity();
			}else if (TypeEnum.SELL.getCode().equals(type)) {
				amtInteger = 0 - transactions.getQuantity();
			}
		}
		map.put(serCode, amtInteger);
		print();
	}
	
	private  void  print() {
		Iterator<Entry<String,Integer>> entries = map.entrySet().iterator();
		while(entries.hasNext()){
		    Entry<String, Integer> entry = entries.next();
		    String key = entry.getKey();
		    Integer value = entry.getValue();
		    System.out.println(key+","+ value);
		}
	}

}
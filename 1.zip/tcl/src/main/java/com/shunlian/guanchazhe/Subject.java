package com.shunlian.guanchazhe;

import java.util.Vector;

import com.shunlian.pojo.Transactions;

public class Subject {

    //�۲�������
    private Vector<Observer> oVector = new Vector<Observer>();

    //����һ���۲���
    public void addObserver(Observer observer) {
        this.oVector.add(observer);
    }

    //ɾ��һ���۲���
    public void deleteObserver(Observer observer) {
        this.oVector.remove(observer);
    }

    //֪ͨ���й۲���
    public void notifyObserver(Transactions transactions) {
        for(Observer observer : this.oVector) {
            observer.change(transactions);
        }
    }

}
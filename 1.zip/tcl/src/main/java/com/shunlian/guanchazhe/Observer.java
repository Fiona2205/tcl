package com.shunlian.guanchazhe;

import com.shunlian.pojo.Transactions;

public interface Observer {
	public void change(Transactions transactions);
}

package com.shunlian.enums;

public enum ActionEnum {
	INSERT("INSERT"),
	CANCEL("CANCEL"),
	UPDATE("UPDATE");
	
	private String code;
	
	ActionEnum(String code){
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}

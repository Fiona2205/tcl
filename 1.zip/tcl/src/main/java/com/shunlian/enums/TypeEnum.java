package com.shunlian.enums;

public enum TypeEnum {
	BUY("Buy"),
	SELL("Sell");
	
	private String code;
	
	TypeEnum(String code){
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
